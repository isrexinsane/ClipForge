// ExportSuccessScreen.jsx
// Redesigned Export Success state for the Trim Modal.
// Vertically-centered content stack; preview letterboxes inside a max-sized frame.

const VERMILLION = '#EF3340';
const SECONDARY  = '#968C83';
const BG         = '#000000';

// ─────────────────────────────────────────────────────────────
// Phone frame — iPhone 17 Pro Max 393 × 852 @1x
// ─────────────────────────────────────────────────────────────
function PhoneFrame({ children, showAnnotations = false }) {
  return (
    <div style={{
      width: 393, height: 852,
      background: BG,
      position: 'relative',
      overflow: 'hidden',
      fontFamily: '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace',
      color: '#fff',
    }}>
      {/* Status bar — iOS (time left, notch, indicators right) */}
      <StatusBar />
      {children}
      {/* Home indicator */}
      <div style={{
        position: 'absolute', left: '50%', bottom: 8,
        transform: 'translateX(-50%)',
        width: 134, height: 5, borderRadius: 3,
        background: 'rgba(255,255,255,0.55)',
      }} />
    </div>
  );
}

function StatusBar() {
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0,
      height: 59, padding: '18px 32px 0',
      display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
      fontFamily: '-apple-system, SF Pro Text, system-ui, sans-serif',
      fontWeight: 600, fontSize: 17, color: '#fff',
      zIndex: 20, pointerEvents: 'none',
    }}>
      <span style={{ letterSpacing: -0.3 }}>9:41</span>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center', paddingTop: 4 }}>
        {/* signal */}
        <svg width="18" height="10" viewBox="0 0 18 10" fill="#fff"><rect x="0" y="6" width="3" height="4" rx="0.5"/><rect x="5" y="4" width="3" height="6" rx="0.5"/><rect x="10" y="2" width="3" height="8" rx="0.5"/><rect x="15" y="0" width="3" height="10" rx="0.5"/></svg>
        {/* wifi */}
        <svg width="16" height="11" viewBox="0 0 16 11" fill="#fff"><path d="M8 10.5a1.3 1.3 0 110-2.5 1.3 1.3 0 010 2.5zm3.1-3.3a4.4 4.4 0 00-6.2 0l-1-1a5.8 5.8 0 018.2 0l-1 1zm2.6-2.6a8 8 0 00-11.4 0L1.3 3.5a9.5 9.5 0 0113.4 0l-1 1.1z"/></svg>
        {/* battery */}
        <svg width="26" height="11" viewBox="0 0 26 11" fill="none">
          <rect x="0.5" y="0.5" width="22" height="10" rx="2.5" stroke="#fff" strokeOpacity="0.4" />
          <rect x="2" y="2" width="19" height="7" rx="1.2" fill="#fff" />
          <rect x="23.5" y="3.5" width="1.5" height="4" rx="0.5" fill="#fff" fillOpacity="0.4" />
        </svg>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// "Done" chip — top-right, Liquid-Glass style
// ─────────────────────────────────────────────────────────────
function DoneChip() {
  return (
    <div style={{
      position: 'absolute', top: 64, right: 16,
      height: 36, padding: '0 18px',
      borderRadius: 18,
      background: 'rgba(235,235,245,0.18)',
      backdropFilter: 'blur(20px)',
      display: 'flex', alignItems: 'center',
      fontFamily: '-apple-system, SF Pro Text, system-ui, sans-serif',
      fontWeight: 500, fontSize: 15, color: '#fff',
      zIndex: 10,
    }}>Done</div>
  );
}

// ─────────────────────────────────────────────────────────────
// GIF preview — letterboxed in a fixed-width container that
// scales to the clip's aspect ratio (up to a maxHeight cap).
// ─────────────────────────────────────────────────────────────
function GifPreview({ aspect = 16 / 9, label = 'LANDSCAPE GIF', hue = 20 }) {
  // Container width is fixed at 361px (393 − 2×16 margins).
  // Height = width / aspect, capped at 520 so ultra-tall clips don't overflow.
  const FRAME_W = 361;
  const h = Math.min(520, FRAME_W / aspect);
  const w = Math.min(FRAME_W, h * aspect);

  return (
    <div style={{
      width: FRAME_W, height: h,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>
      <div style={{
        width: w, height: h,
        borderRadius: 14,
        overflow: 'hidden',
        position: 'relative',
        background: `linear-gradient(135deg, oklch(0.55 0.15 ${hue}) 0%, oklch(0.35 0.12 ${hue + 30}) 100%)`,
        boxShadow: '0 8px 28px rgba(0,0,0,0.4)',
      }}>
        {/* Subtle stripe placeholder so it reads as "media, not designed by me" */}
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'repeating-linear-gradient(135deg, rgba(255,255,255,0.06) 0 6px, transparent 6px 14px)',
        }} />
        {/* GIF label + looping dot */}
        <div style={{
          position: 'absolute', top: 12, left: 12,
          display: 'flex', alignItems: 'center', gap: 6,
          padding: '4px 8px', borderRadius: 4,
          background: 'rgba(0,0,0,0.45)', backdropFilter: 'blur(8px)',
          fontFamily: 'JetBrains Mono, ui-monospace, monospace',
          fontSize: 9, letterSpacing: 1, color: 'rgba(255,255,255,0.85)',
        }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: VERMILLION, animation: 'dot 1.2s ease-in-out infinite' }} />
          GIF
        </div>
        <div style={{
          position: 'absolute', inset: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'JetBrains Mono, ui-monospace, monospace',
          fontSize: 11, letterSpacing: 2, color: 'rgba(255,255,255,0.65)',
          textTransform: 'uppercase',
        }}>{label}</div>
        {/* Watermark (free tier) */}
        <div style={{
          position: 'absolute', bottom: 10, right: 10,
          fontFamily: 'JetBrains Mono, ui-monospace, monospace',
          fontWeight: 500, fontSize: 10, letterSpacing: 1.5,
          color: 'rgba(255,255,255,0.55)',
        }}>CLIPFORGE</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Buttons
// ─────────────────────────────────────────────────────────────
function ShareButton() {
  return (
    <button style={{
      flex: 1, height: 52, borderRadius: 26,
      background: VERMILLION, border: 'none',
      fontFamily: 'JetBrains Mono, ui-monospace, monospace',
      fontWeight: 500, fontSize: 15, letterSpacing: 1.5,
      color: '#fff', cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    }}>
      <svg width="16" height="18" viewBox="0 0 16 18" fill="none" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M8 1v11" /><path d="M4 5l4-4 4 4" /><path d="M1 11v4a2 2 0 002 2h10a2 2 0 002-2v-4" />
      </svg>
      SHARE
    </button>
  );
}
function DoneButton() {
  return (
    <button style={{
      flex: 1, height: 52, borderRadius: 26,
      background: 'transparent',
      border: '1.5px solid rgba(255,255,255,0.85)',
      fontFamily: 'JetBrains Mono, ui-monospace, monospace',
      fontWeight: 500, fontSize: 15, letterSpacing: 1.5,
      color: '#fff', cursor: 'pointer',
    }}>DONE</button>
  );
}

// ─────────────────────────────────────────────────────────────
// The centered content stack — the core design move.
// Uses flex column with justify-content: center so the whole
// block floats in the vertical center of the safe area.
// ─────────────────────────────────────────────────────────────
function ExportSuccess({ aspect, label, fileInfo = '3.9 MB · 360 × 640', hue = 20, remaining = '0 of 1' }) {
  return (
    <>
      <DoneChip />
      <div style={{
        position: 'absolute',
        top: 100,           // below status bar + Done chip
        bottom: 34,         // above home indicator
        left: 0, right: 0,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center', // ← vertical centering
        alignItems: 'center',
        padding: '0 16px',
        gap: 0,
      }}>
        <GifPreview aspect={aspect} label={label} hue={hue} />

        <div style={{ height: 20 }} />
        <div style={{
          fontFamily: 'JetBrains Mono, ui-monospace, monospace',
          fontSize: 13, letterSpacing: 0.3, color: '#fff',
        }}>{fileInfo}</div>

        <div style={{ height: 24 }} />
        <div style={{ display: 'flex', gap: 12, width: '100%' }}>
          <ShareButton />
          <DoneButton />
        </div>

        <div style={{ height: 16 }} />
        <div style={{
          fontFamily: 'JetBrains Mono, ui-monospace, monospace',
          fontSize: 11, letterSpacing: 0.2, color: SECONDARY,
        }}>{remaining} free GIFs remaining today</div>
      </div>
    </>
  );
}

Object.assign(window, {
  PhoneFrame, ExportSuccess, GifPreview,
  ShareButton, DoneButton, DoneChip,
  VERMILLION, SECONDARY,
});
