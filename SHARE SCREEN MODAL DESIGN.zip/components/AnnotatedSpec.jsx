// AnnotatedSpec.jsx — overlays red dimension/measurement lines on top of a PhoneFrame
// Designed to sit inside a DCArtboard at 393 × 852.

const ANN = '#FF2D55';        // annotation line color
const ANN_BG = '#FFDCE0';     // annotation label bg
const ANN_TEXT = '#7A0018';   // annotation text

function AnnLine({ x1, y1, x2, y2, endcaps = true }) {
  const ext = 4;
  return (
    <svg style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'visible' }}>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={ANN} strokeWidth={1} />
      {endcaps && x1 === x2 && (
        <>
          <line x1={x1 - ext} y1={y1} x2={x1 + ext} y2={y1} stroke={ANN} strokeWidth={1} />
          <line x1={x2 - ext} y1={y2} x2={x2 + ext} y2={y2} stroke={ANN} strokeWidth={1} />
        </>
      )}
      {endcaps && y1 === y2 && (
        <>
          <line x1={x1} y1={y1 - ext} x2={x1} y2={y1 + ext} stroke={ANN} strokeWidth={1} />
          <line x1={x2} y1={y2 - ext} x2={x2} y2={y2 + ext} stroke={ANN} strokeWidth={1} />
        </>
      )}
    </svg>
  );
}

function AnnLabel({ x, y, children, align = 'center' }) {
  return (
    <div style={{
      position: 'absolute',
      left: x, top: y,
      transform: align === 'center' ? 'translate(-50%, -50%)'
               : align === 'right'  ? 'translate(-100%, -50%)'
               : 'translate(0, -50%)',
      background: ANN_BG, color: ANN_TEXT,
      padding: '2px 6px', borderRadius: 3,
      fontFamily: 'JetBrains Mono, ui-monospace, monospace',
      fontSize: 10, fontWeight: 600, whiteSpace: 'nowrap',
      border: `1px solid ${ANN}`,
      zIndex: 30,
    }}>{children}</div>
  );
}

function AnnBox({ top, left, width, height, label, labelPos = 'top' }) {
  return (
    <>
      <div style={{
        position: 'absolute', top, left, width, height,
        border: `1px dashed ${ANN}`,
        boxSizing: 'border-box',
        pointerEvents: 'none',
      }} />
      {label && (
        <AnnLabel
          x={labelPos === 'top' ? left + width / 2 : left + width + 8}
          y={labelPos === 'top' ? top - 10 : top + height / 2}
          align={labelPos === 'top' ? 'center' : 'left'}
        >{label}</AnnLabel>
      )}
    </>
  );
}

// Vertical dimension (double-ended arrow) with a label
function VDim({ x, y1, y2, label, labelSide = 'right' }) {
  const cy = (y1 + y2) / 2;
  return (
    <>
      <AnnLine x1={x} y1={y1} x2={x} y2={y2} />
      <AnnLabel
        x={labelSide === 'right' ? x + 10 : x - 10}
        y={cy}
        align={labelSide === 'right' ? 'left' : 'right'}
      >{label}</AnnLabel>
    </>
  );
}

function HDim({ y, x1, x2, label }) {
  const cx = (x1 + x2) / 2;
  return (
    <>
      <AnnLine x1={x1} y1={y} x2={x2} y2={y} />
      <AnnLabel x={cx} y={y - 10}>{label}</AnnLabel>
    </>
  );
}

Object.assign(window, { AnnLine, AnnLabel, AnnBox, VDim, HDim });
